# VAMOS — Android Offline Starter

هذه نسخة أولية عملية لتحويل واجهة VAMOS الحالية إلى تطبيق Android مستقل يعمل محلياً.

## ما تم تحسينه
- الحفاظ على تصميم VAMOS الحالي وهوية الأسود والأصفر.
- تجهيز التطبيق كـ PWA مع manifest وأيقونات.
- إضافة Service Worker لتخزين ملفات الواجهة الأساسية عند أول تشغيل من HTTPS/localhost.
- إزالة تحميل الخطوط من Google حتى لا يعتمد شكل التطبيق على اتصال خارجي.
- حفظ الطلبات والمحادثات التجريبية محلياً بجانب التفضيلات والملف الشخصي.
- استعادة البيانات المحلية عند إعادة فتح التطبيق.
- إضافة دعم زر الرجوع في Android عند توفر Capacitor App plugin.
- تجهيز Capacitor config وملف package.json للبدء ببناء Android.

## حدود النسخة
- لا يوجد Backend ولا حسابات حقيقية.
- الطلبات والمحادثات والمتطوعون بيانات محلية تجريبية على هذا الجهاز فقط.
- مكالمة Jitsi تحتاج إنترنت وتفتح خدمة خارجية؛ ليست مكالمة محلية أو نظام مكالمات خاصاً بالتطبيق.
- الخريطة الحالية توضيحية وليست خريطة حقيقية.
- تثبيت APK يحتاج بيئة بناء Android. ملفات HTML وحدها لا تنتج APK.

## بناء APK
يتطلب جهاز كمبيوتر عليه Node.js وAndroid Studio وAndroid SDK.

1. فك ضغط المجلد.
2. افتح الطرفية داخل مجلد المشروع.
3. نفّذ:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. من Android Studio اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5. اختبر APK على هاتف Android.

إذا كان مجلد `android` موجوداً مسبقاً فلا تنفذ `npx cap add android` مرة ثانية؛ استخدم `npx cap sync android`.

## اختبار PWA
ضع محتويات مجلد `www` على استضافة HTTPS أو شغّلها محلياً عبر localhost. افتحها في Chrome على Android ثم اختر Install app / Add to Home screen. يحتاج Service Worker إلى HTTPS أو localhost.

## ملاحظة SPCK
يمكن فتح وتحرير `www/index.html` من SPCK، لكن إنشاء APK أصلي يتطلب Capacitor وأدوات Android خارج SPCK.
